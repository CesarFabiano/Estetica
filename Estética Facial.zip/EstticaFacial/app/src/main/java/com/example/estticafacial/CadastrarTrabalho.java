package com.example.estticafacial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.estticafacial.model.Trabalho;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CadastrarTrabalho extends AppCompatActivity {

    EditText editNome;
    EditText editPreco;
    EditText editImagem;
    EditText editVideo;
    Button btnCadastrar;
    FirebaseDatabase database;
    DatabaseReference referenceTrabalho;
    String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_trabalho);

        editNome = findViewById(R.id.editNome);
        editPreco = findViewById(R.id.editPreco);
        editImagem = findViewById(R.id.editImagem);
        editVideo = findViewById(R.id.editVideo);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        database = FirebaseDatabase.getInstance();
        referenceTrabalho = database.getReference("trabalhos");

        Bundle b = getIntent().getExtras();
        if(b == null) {
            key = "";
            getSupportActionBar().setTitle("Cadastrar");
        } else {
            key = b.getString("key");
            getSupportActionBar().setTitle("Atualizar");
            btnCadastrar.setText("Atualizar");
            referenceTrabalho.child(key).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Trabalho trabalho = snapshot.getValue(Trabalho.class);
                    editNome.setText(trabalho.nome);
                    editPreco.setText(String.valueOf(trabalho.preco));
                    editImagem.setText(trabalho.imagem);
                    editVideo.setText(trabalho.video);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(CadastrarTrabalho.this, "Erro ao consultar dados!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = editNome.getText().toString();
                String prec = editPreco.getText().toString();
                double preco = Double.parseDouble(prec);
                String imagem = editImagem.getText().toString();
                String video = editVideo.getText().toString();
                Trabalho trabalho = new Trabalho(nome,imagem,video,preco);
                if(key.equals("")){
                    referenceTrabalho.push().setValue(trabalho);
                    Toast.makeText(CadastrarTrabalho.this, "Novidade cadastrada!!", Toast.LENGTH_SHORT).show();
                } else {
                    referenceTrabalho.child(key).setValue(trabalho);
                    Toast.makeText(CadastrarTrabalho.this, "Trabalho atualizado com sucesso", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });
    }
}